package org.androidtown.appsite;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

/**
 * Created by K on 2015-11-02.
 */
public class mainSite extends Activity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        TextView topTitle = (TextView) findViewById(R.id.topTitle);
        topTitle.setText(R.string.main_name);

        ImageButton top_arrow_left = (ImageButton) findViewById(R.id.top_arrow_left);

        top_arrow_left.setOnClickListener(new ImageButton.OnClickListener(){
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        ImageButton top_arrow_right = (ImageButton) findViewById(R.id.top_arrow_right);
        top_arrow_right.setVisibility(View.INVISIBLE);

    }
}
