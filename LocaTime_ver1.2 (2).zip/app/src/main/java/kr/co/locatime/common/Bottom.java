package kr.co.locatime.common;

/**
 * Created by Joonha on 2015-12-03.
 */
public class Bottom {
}
